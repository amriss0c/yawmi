// lib/utils/hijri_helper.dart

import 'package:hijri/hijri_calendar.dart';

class HijriHelper {
  /// Returns Hijri date string for a given Gregorian date
  /// Format: "١٤ رمضان" or "14 Ramadan" based on locale
  static String getHijriDateString(DateTime date, {bool arabic = true}) {
    final hijri = HijriCalendar.fromDate(date);
    if (arabic) {
      return '${_toArabicNumerals(hijri.hDay)} ${_hijriMonthArabic(hijri.hMonth)}';
    }
    return '${hijri.hDay} ${hijri.longMonthName}';
  }

  static String getHijriFullString(DateTime date) {
    final hijri = HijriCalendar.fromDate(date);
    return '${hijri.hDay} ${hijri.longMonthName} ${hijri.hYear}';
  }

  static String getGregorianMonthYear(DateTime date, {bool arabic = false}) {
    const monthsEn = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const monthsAr = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    final month = arabic ? monthsAr[date.month - 1] : monthsEn[date.month - 1];
    return '$month ${date.year}';
  }

  static String getHijriMonthYear(DateTime date) {
    final hijri = HijriCalendar.fromDate(date);
    return '${hijri.longMonthName} ${hijri.hYear}';
  }

  static String _toArabicNumerals(int number) {
    const western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    String result = number.toString();
    for (int i = 0; i < western.length; i++) {
      result = result.replaceAll(western[i], arabic[i]);
    }
    return result;
  }

  static String _hijriMonthArabic(int month) {
    const months = [
      'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر',
      'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان',
      'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
    ];
    return months[month - 1];
  }
}
