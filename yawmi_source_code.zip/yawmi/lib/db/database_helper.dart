// lib/db/database_helper.dart

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/day_task.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('yawmi.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE tasks (
        date TEXT PRIMARY KEY,
        taskText TEXT NOT NULL,
        status INTEGER NOT NULL
      )
    ''');
  }

  Future<DayTask?> getTask(String date) async {
    final db = await database;
    final result = await db.query('tasks', where: 'date = ?', whereArgs: [date]);
    if (result.isEmpty) return null;
    return DayTask.fromMap(result.first);
  }

  Future<Map<String, DayTask>> getTasksForMonth(int year, int month) async {
    final db = await database;
    final prefix = '${year.toString().padLeft(4, '0')}-${month.toString().padLeft(2, '0')}';
    final result = await db.query(
      'tasks',
      where: 'date LIKE ?',
      whereArgs: ['$prefix%'],
    );
    final Map<String, DayTask> map = {};
    for (final row in result) {
      final task = DayTask.fromMap(row);
      map[task.date] = task;
    }
    return map;
  }

  Future<void> upsertTask(DayTask task) async {
    final db = await database;
    await db.insert(
      'tasks',
      task.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteTask(String date) async {
    final db = await database;
    await db.delete('tasks', where: 'date = ?', whereArgs: [date]);
  }

  Future<DayTask?> getTodayTask() async {
    final today = DateTime.now();
    final dateStr =
        '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
    return getTask(dateStr);
  }
}
