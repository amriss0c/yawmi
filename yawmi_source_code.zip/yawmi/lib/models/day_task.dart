// lib/models/day_task.dart

enum TaskStatus { none, done, notDone }

class DayTask {
  final String date; // YYYY-MM-DD — primary key
  final String taskText;
  final TaskStatus status;

  DayTask({
    required this.date,
    required this.taskText,
    required this.status,
  });

  Map<String, dynamic> toMap() {
    return {
      'date': date,
      'taskText': taskText,
      'status': status.index,
    };
  }

  factory DayTask.fromMap(Map<String, dynamic> map) {
    return DayTask(
      date: map['date'] as String,
      taskText: map['taskText'] as String,
      status: TaskStatus.values[map['status'] as int],
    );
  }

  DayTask copyWith({
    String? date,
    String? taskText,
    TaskStatus? status,
  }) {
    return DayTask(
      date: date ?? this.date,
      taskText: taskText ?? this.taskText,
      status: status ?? this.status,
    );
  }
}
