// lib/providers/task_provider.dart

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../db/database_helper.dart';
import '../models/day_task.dart';
import '../services/notification_service.dart';

class TaskProvider extends ChangeNotifier {
  Map<String, DayTask> _monthTasks = {};
  DateTime _focusedMonth = DateTime.now();
  bool _notificationsEnabled = true;
  int _reminderHour = 18;
  int _reminderMinute = 0;
  bool _startOnSaturday = true; // Default: week starts Saturday
  bool _arabicMode = true;

  Map<String, DayTask> get monthTasks => _monthTasks;
  DateTime get focusedMonth => _focusedMonth;
  bool get notificationsEnabled => _notificationsEnabled;
  int get reminderHour => _reminderHour;
  int get reminderMinute => _reminderMinute;
  bool get startOnSaturday => _startOnSaturday;
  bool get arabicMode => _arabicMode;

  Future<void> init() async {
    await _loadPreferences();
    await loadMonthTasks();
    await NotificationService.instance.init();
    await _rescheduleNotification();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _notificationsEnabled = prefs.getBool('notif_enabled') ?? true;
    _reminderHour = prefs.getInt('reminder_hour') ?? 18;
    _reminderMinute = prefs.getInt('reminder_minute') ?? 0;
    _startOnSaturday = prefs.getBool('start_saturday') ?? true;
    _arabicMode = prefs.getBool('arabic_mode') ?? true;
    notifyListeners();
  }

  Future<void> loadMonthTasks() async {
    _monthTasks = await DatabaseHelper.instance
        .getTasksForMonth(_focusedMonth.year, _focusedMonth.month);
    notifyListeners();
  }

  DayTask? getTask(DateTime date) {
    final key = _dateKey(date);
    return _monthTasks[key];
  }

  Future<void> saveTask(DateTime date, String text, TaskStatus status) async {
    final key = _dateKey(date);
    final task = DayTask(date: key, taskText: text, status: status);
    await DatabaseHelper.instance.upsertTask(task);
    _monthTasks[key] = task;
    notifyListeners();
  }

  Future<void> deleteTask(DateTime date) async {
    final key = _dateKey(date);
    await DatabaseHelper.instance.deleteTask(key);
    _monthTasks.remove(key);
    notifyListeners();
  }

  void goToPreviousMonth() {
    _focusedMonth = DateTime(_focusedMonth.year, _focusedMonth.month - 1);
    loadMonthTasks();
  }

  void goToNextMonth() {
    _focusedMonth = DateTime(_focusedMonth.year, _focusedMonth.month + 1);
    loadMonthTasks();
  }

  void goToToday() {
    _focusedMonth = DateTime.now();
    loadMonthTasks();
  }

  Future<void> setNotificationsEnabled(bool value) async {
    _notificationsEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notif_enabled', value);
    await _rescheduleNotification();
    notifyListeners();
  }

  Future<void> setReminderTime(int hour, int minute) async {
    _reminderHour = hour;
    _reminderMinute = minute;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('reminder_hour', hour);
    await prefs.setInt('reminder_minute', minute);
    await _rescheduleNotification();
    notifyListeners();
  }

  Future<void> setStartOnSaturday(bool value) async {
    _startOnSaturday = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('start_saturday', value);
    notifyListeners();
  }

  Future<void> setArabicMode(bool value) async {
    _arabicMode = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('arabic_mode', value);
    notifyListeners();
  }

  Future<void> _rescheduleNotification() async {
    await NotificationService.instance.scheduleDailyReminder(
      hour: _reminderHour,
      minute: _reminderMinute,
      enabled: _notificationsEnabled,
    );
  }

  String _dateKey(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}
