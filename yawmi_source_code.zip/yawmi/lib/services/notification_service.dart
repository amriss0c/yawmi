// lib/services/notification_service.dart

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import '../db/database_helper.dart';
import '../models/day_task.dart';

class NotificationService {
  static final NotificationService instance = NotificationService._();
  NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    tz.initializeTimeZones();

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidSettings);

    await _plugin.initialize(initSettings);
    _initialized = true;
  }

  Future<void> scheduleDailyReminder({
    required int hour,
    required int minute,
    required bool enabled,
  }) async {
    await _plugin.cancelAll();
    if (!enabled) return;

    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }

    const androidDetails = AndroidNotificationDetails(
      'yawmi_daily',
      'Daily Reminder',
      channelDescription: 'Reminds you to set or complete your daily task',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(android: androidDetails);

    await _plugin.zonedSchedule(
      0,
      'يومي — تذكير يومي',
      'جاري التحقق من مهمة اليوم...',
      scheduled,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// Call this at notification time to build the correct message
  Future<void> showSmartReminder() async {
    final task = await DatabaseHelper.instance.getTodayTask();

    String title = 'يومي 📅';
    String body;

    if (task == null || task.taskText.trim().isEmpty) {
      body = 'لم تسجّل مهمة لهذا اليوم بعد 📝';
    } else if (task.status != TaskStatus.done) {
      body = 'لا تنسَ مهمتك: ${task.taskText} ⏰';
    } else {
      return; // Task is done — no notification
    }

    const androidDetails = AndroidNotificationDetails(
      'yawmi_smart',
      'Smart Daily Reminder',
      channelDescription: 'Context-aware daily task reminder',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(android: androidDetails);

    await _plugin.show(1, title, body, details);
  }

  Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }
}
