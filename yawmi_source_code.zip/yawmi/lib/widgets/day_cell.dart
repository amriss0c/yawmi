// lib/widgets/day_cell.dart

import 'package:flutter/material.dart';
import '../models/day_task.dart';
import '../utils/hijri_helper.dart';

class DayCell extends StatelessWidget {
  final DateTime date;
  final DayTask? task;
  final bool isToday;
  final bool isCurrentMonth;
  final VoidCallback onTap;

  const DayCell({
    super.key,
    required this.date,
    required this.task,
    required this.isToday,
    required this.isCurrentMonth,
    required this.onTap,
  });

  Color get _indicatorColor {
    if (task == null || task!.taskText.trim().isEmpty) {
      return Colors.grey.shade400;
    }
    switch (task!.status) {
      case TaskStatus.done:
        return const Color(0xFF4CAF50);
      case TaskStatus.notDone:
        return const Color(0xFFF44336);
      case TaskStatus.none:
        return Colors.grey.shade400;
    }
  }

  bool get _hasTask =>
      task != null && task!.taskText.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final textColor = isCurrentMonth
        ? (isToday ? Colors.white : Colors.black87)
        : Colors.black26;

    final hijriStr = HijriHelper.getHijriDateString(date, arabic: true);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: isToday ? const Color(0xFF1A6B4A) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isToday
                ? const Color(0xFF1A6B4A)
                : Colors.grey.shade200,
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Gregorian day number
            Text(
              '${date.day}',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
            // Hijri date
            Text(
              hijriStr,
              style: TextStyle(
                fontSize: 8,
                color: isToday ? Colors.white70 : Colors.grey.shade500,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 3),
            // Status indicator dot
            Container(
              width: 7,
              height: 7,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isCurrentMonth ? _indicatorColor : Colors.transparent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
