// lib/widgets/day_detail_sheet.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/day_task.dart';
import '../providers/task_provider.dart';
import '../utils/hijri_helper.dart';

class DayDetailSheet extends StatefulWidget {
  final DateTime date;

  const DayDetailSheet({super.key, required this.date});

  @override
  State<DayDetailSheet> createState() => _DayDetailSheetState();
}

class _DayDetailSheetState extends State<DayDetailSheet> {
  late TextEditingController _controller;
  TaskStatus _status = TaskStatus.none;
  bool _hasChanges = false;

  @override
  void initState() {
    super.initState();
    final provider = context.read<TaskProvider>();
    final task = provider.getTask(widget.date);
    _controller = TextEditingController(text: task?.taskText ?? '');
    _status = task?.status ?? TaskStatus.none;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save(TaskProvider provider) async {
    final text = _controller.text.trim();
    if (text.isEmpty) {
      await provider.deleteTask(widget.date);
    } else {
      final statusToSave =
          _status == TaskStatus.none ? TaskStatus.notDone : _status;
      await provider.saveTask(widget.date, text, statusToSave);
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TaskProvider>();
    final gregorianStr =
        '${widget.date.day}/${widget.date.month}/${widget.date.year}';
    final hijriStr = HijriHelper.getHijriFullString(widget.date);

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle bar
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Date header
          Row(
            children: [
              const Icon(Icons.calendar_today,
                  color: Color(0xFF1A6B4A), size: 20),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(gregorianStr,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(hijriStr,
                      style: TextStyle(
                          color: Colors.grey.shade600, fontSize: 12)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Task text field
          TextField(
            controller: _controller,
            autofocus: true,
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'أدخل مهمة اليوم...',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    const BorderSide(color: Color(0xFF1A6B4A), width: 2),
              ),
            ),
            onChanged: (_) => setState(() => _hasChanges = true),
          ),
          const SizedBox(height: 16),

          // Status buttons
          Row(
            children: [
              Expanded(
                child: _StatusButton(
                  label: '✅ منجزة',
                  selected: _status == TaskStatus.done,
                  color: const Color(0xFF4CAF50),
                  onTap: () => setState(() {
                    _status = TaskStatus.done;
                    _hasChanges = true;
                  }),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _StatusButton(
                  label: '❌ غير منجزة',
                  selected: _status == TaskStatus.notDone,
                  color: const Color(0xFFF44336),
                  onTap: () => setState(() {
                    _status = TaskStatus.notDone;
                    _hasChanges = true;
                  }),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Save button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1A6B4A),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => _save(provider),
              child: const Text('حفظ',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
            ),
          ),

          // Delete button (if task exists)
          if (provider.getTask(widget.date) != null) ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () async {
                  await provider.deleteTask(widget.date);
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('حذف المهمة',
                    style: TextStyle(color: Colors.red)),
              ),
            ),
          ],
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class _StatusButton extends StatelessWidget {
  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;

  const _StatusButton({
    required this.label,
    required this.selected,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.15) : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? color : Colors.grey.shade300,
            width: selected ? 2 : 1,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? color : Colors.grey.shade600,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}
