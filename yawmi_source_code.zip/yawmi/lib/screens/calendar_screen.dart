// lib/screens/calendar_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/task_provider.dart';
import '../utils/hijri_helper.dart';
import '../widgets/day_cell.dart';
import '../widgets/day_detail_sheet.dart';
import 'settings_screen.dart';

class CalendarScreen extends StatelessWidget {
  const CalendarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F9FA),
        appBar: _buildAppBar(context),
        body: Consumer<TaskProvider>(
          builder: (context, provider, _) {
            return Column(
              children: [
                _buildMonthHeader(context, provider),
                _buildWeekDayHeaders(provider),
                Expanded(
                  child: _buildCalendarGrid(context, provider),
                ),
                _buildLegend(),
              ],
            );
          },
        ),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: const Color(0xFF1A6B4A),
      title: const Text(
        'يومي',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 22,
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: const Icon(Icons.today, color: Colors.white),
          onPressed: () => context.read<TaskProvider>().goToToday(),
          tooltip: 'اليوم',
        ),
        IconButton(
          icon: const Icon(Icons.settings, color: Colors.white),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SettingsScreen()),
          ),
        ),
      ],
    );
  }

  Widget _buildMonthHeader(BuildContext context, TaskProvider provider) {
    final month = provider.focusedMonth;
    final gregorianLabel =
        HijriHelper.getGregorianMonthYear(month, arabic: provider.arabicMode);
    final hijriLabel = HijriHelper.getHijriMonthYear(month);

    return Container(
      color: const Color(0xFF1A6B4A),
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left, color: Colors.white),
            onPressed: provider.goToNextMonth,
          ),
          Column(
            children: [
              Text(
                gregorianLabel,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                hijriLabel,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.chevron_right, color: Colors.white),
            onPressed: provider.goToPreviousMonth,
          ),
        ],
      ),
    );
  }

  Widget _buildWeekDayHeaders(TaskProvider provider) {
    final days = provider.startOnSaturday
        ? ['سبت', 'أحد', 'اثن', 'ثلث', 'أرب', 'خمس', 'جمع']
        : ['أحد', 'اثن', 'ثلث', 'أرب', 'خمس', 'جمع', 'سبت'];

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: days
            .map((d) => Expanded(
                  child: Center(
                    child: Text(
                      d,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        color: Color(0xFF1A6B4A),
                      ),
                    ),
                  ),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildCalendarGrid(BuildContext context, TaskProvider provider) {
    final month = provider.focusedMonth;
    final today = DateTime.now();
    final firstDay = DateTime(month.year, month.month, 1);
    final lastDay = DateTime(month.year, month.month + 1, 0);

    // Calculate offset for week start
    int startOffset = firstDay.weekday; // 1=Mon, 7=Sun
    if (provider.startOnSaturday) {
      // Saturday = 6, so offset: Sat=0, Sun=1, Mon=2...
      startOffset = (firstDay.weekday + 1) % 7;
    } else {
      // Sunday = 0 offset
      startOffset = firstDay.weekday % 7;
    }

    final List<DateTime?> cells = [
      ...List.filled(startOffset, null),
      ...List.generate(lastDay.day, (i) => DateTime(month.year, month.month, i + 1)),
    ];

    // Pad to complete last row
    while (cells.length % 7 != 0) cells.add(null);

    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        childAspectRatio: 0.75,
      ),
      itemCount: cells.length,
      itemBuilder: (context, index) {
        final date = cells[index];
        if (date == null) {
          return const SizedBox();
        }
        final isToday = date.year == today.year &&
            date.month == today.month &&
            date.day == today.day;
        final task = provider.getTask(date);

        return DayCell(
          date: date,
          task: task,
          isToday: isToday,
          isCurrentMonth: true,
          onTap: () => _openDayDetail(context, date),
        );
      },
    );
  }

  void _openDayDetail(BuildContext context, DateTime date) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => DayDetailSheet(date: date),
    );
  }

  Widget _buildLegend() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _legendItem(const Color(0xFF4CAF50), 'منجزة'),
          const SizedBox(width: 20),
          _legendItem(const Color(0xFFF44336), 'غير منجزة'),
          const SizedBox(width: 20),
          _legendItem(Colors.grey.shade400, 'لا مهمة'),
        ],
      ),
    );
  }

  Widget _legendItem(Color color, String label) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        ),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ],
    );
  }
}
