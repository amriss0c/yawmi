// lib/screens/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/task_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A6B4A),
          title: const Text('الإعدادات',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: Consumer<TaskProvider>(
          builder: (context, provider, _) {
            return ListView(
              children: [
                _sectionHeader('التذكيرات'),
                SwitchListTile(
                  title: const Text('تفعيل التذكير اليومي'),
                  subtitle: const Text('تذكير إذا لم تُسجَّل مهمة أو لم تُنجَز'),
                  value: provider.notificationsEnabled,
                  activeColor: const Color(0xFF1A6B4A),
                  onChanged: (v) => provider.setNotificationsEnabled(v),
                ),
                if (provider.notificationsEnabled)
                  ListTile(
                    title: const Text('وقت التذكير'),
                    subtitle: Text(
                        _formatTime(provider.reminderHour, provider.reminderMinute)),
                    leading: const Icon(Icons.access_time,
                        color: Color(0xFF1A6B4A)),
                    onTap: () => _pickTime(context, provider),
                  ),
                const Divider(),
                _sectionHeader('التقويم'),
                SwitchListTile(
                  title: const Text('بدء الأسبوع من السبت'),
                  subtitle: const Text('إيقاف لبدء الأسبوع من الأحد'),
                  value: provider.startOnSaturday,
                  activeColor: const Color(0xFF1A6B4A),
                  onChanged: (v) => provider.setStartOnSaturday(v),
                ),
                const Divider(),
                _sectionHeader('اللغة'),
                SwitchListTile(
                  title: const Text('عرض التواريخ بالعربية'),
                  value: provider.arabicMode,
                  activeColor: const Color(0xFF1A6B4A),
                  onChanged: (v) => provider.setArabicMode(v),
                ),
                const Divider(),
                _sectionHeader('عن التطبيق'),
                const ListTile(
                  title: Text('يومي'),
                  subtitle: Text('تتبع مهامك اليومية بالتقويم الميلادي والهجري\nالإصدار 1.0.0'),
                  leading: Icon(Icons.info_outline, color: Color(0xFF1A6B4A)),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(
        title,
        style: const TextStyle(
          color: Color(0xFF1A6B4A),
          fontWeight: FontWeight.bold,
          fontSize: 13,
        ),
      ),
    );
  }

  String _formatTime(int hour, int minute) {
    final h = hour % 12 == 0 ? 12 : hour % 12;
    final m = minute.toString().padLeft(2, '0');
    final period = hour < 12 ? 'ص' : 'م';
    return '$h:$m $period';
  }

  Future<void> _pickTime(BuildContext context, TaskProvider provider) async {
    final picked = await showTimePicker(
      context: context,
      initialTime:
          TimeOfDay(hour: provider.reminderHour, minute: provider.reminderMinute),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
    );
    if (picked != null) {
      await provider.setReminderTime(picked.hour, picked.minute);
    }
  }
}
