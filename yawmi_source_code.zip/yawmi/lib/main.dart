// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/task_provider.dart';
import 'screens/calendar_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  final taskProvider = TaskProvider();
  await taskProvider.init();

  runApp(
    ChangeNotifierProvider.value(
      value: taskProvider,
      child: const YawmiApp(),
    ),
  );
}

class YawmiApp extends StatelessWidget {
  const YawmiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'يومي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1A6B4A),
        ),
        useMaterial3: true,
        fontFamily: 'sans-serif',
      ),
      home: const CalendarScreen(),
    );
  }
}
